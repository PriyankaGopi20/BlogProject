import AppRoutes from "./AppRoutes";

const App=()=> {
  return (

    <div className="container">
      <div>
      <AppRoutes/>
      </div>
    </div>
  );
}
export default App;