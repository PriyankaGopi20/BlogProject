
class Post{
    userId;
    id;
    title;
    body;
    img;
    constructor(userId,id,title,body,img)
    {
        this.userId=userId;
        this.id=id;
        this.title=title;
        this.body=body;
        this.img=img;
    }
}
export default Post;