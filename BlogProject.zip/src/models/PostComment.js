
class PostComment{
    userId;
    id;
    blogcomment;
    postId;

    constructor(userId,id,blogcomment,postId)
    {
        this.userId=userId;
        this.id=id;
        this.blogcomment=blogcomment;
        this.postId=postId;
    }
}
export default PostComment;