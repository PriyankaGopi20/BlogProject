import Login from "./components/Login";
import Header from "./components/Header";
import Register from "./components/Register";
import Home from "./components/Home";
import ReadPost from "./components/ReadPost";
import Logout from "./components/Logout";
import CreatePost from "./components/CreatePost";
import DeletePost from "./components/DeletePost";
import UpdatePost from "./components/UpdatePost";
import BlogPostComment from "./components/BlogPostComment";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import UpdateComment from "./components/UpdateComment";

//import { useState,useEffect } from "react";
//import AppUser from "./models/AppUser";

const AppRoutes = () => {
    const currentUser = sessionStorage.getItem(`loginStatus`);
    // const [currentUser, setCurrentUser] = useState(new AppUser());

    // useEffect(() => {
    //     setCurrentUser(sessionStorage.getItem(`loginStatus`));
    // }, []);

    return (
        <div>
            <BrowserRouter>
                <div>
                    <Header />
                </div>
                <div>
                    {currentUser &&
                        <div>
                            <Routes>
                                {/* <Route path="/readpost" element={<ReadPost/>}/> */}
                                <Route path="/home" element={<Home />} />
                                <Route path="/logout" element={<Logout/>} />
                                <Route path="/readpost" element={<ReadPost/>}/>
                                <Route path="/createpost" element={<CreatePost/>}/>
                               <Route path="/deletepost" element={<DeletePost/>}/>
                               <Route path="/updatepost" element={<UpdatePost/>}/>
                               <Route path="/blogpostcomment" element={<BlogPostComment/>}/>
                               <Route path="/updatecomment" element={<UpdateComment/>}/>
                            </Routes>
                        </div>
                    }
                    {(!currentUser) &&
                        <div>
                            <Routes>
                                <Route path="/login" element={<Login />} />
                                <Route path="/register" element={<Register />} />
                                
                                {/* <Route path="/login" > <Login /> </Route> */}
                            </Routes>
                        </div>
                    }
                </div>
            </BrowserRouter>
            <div>
                {/* <Footer /> */}
            </div>

        </div>
    );
};

export default AppRoutes;