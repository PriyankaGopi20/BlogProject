import axios from "axios";
import { useEffect, useState } from "react";
import Post from "../models/Post";
import { Link, useNavigate } from "react-router-dom";
import DeletePost from "./DeletePost";

const CreatePost = () => {
    const url = `http://localhost:12345`;
    const [postToPublish, setPostToPublish] = useState({});
    const navigate = useNavigate();

    useEffect(
        () => {
            setPostToPublish(new Post());
        }
        ,
        []
    );

    const postBlogData = (evt) => {
        axios.post(`${url}/posts/`, postToPublish)
            .then((response) => {
                console.log(response.data);
                setPostToPublish({ userId: '', title: '', body: '' });
                alert(`The Post with title ${response.data.title} has been successfully created!!`);
            }).catch((error) => {
                console.log(error.message);
            });
        evt.preventDefault();
    }
    const cancelCreate = () => {
        navigate(-1);
    };

    const handlecreate = (evt) => {
        setPostToPublish({ ...postToPublish, [evt.target.name]: evt.target.value })

    }
    return (
        <div className="container">
            <div
                style={{
                    backgroundImage: `url("https://thumbs.dreamstime.com/b/grey-tech-background-abstract-vector-33109515.jpg")`,
                }} >
                <div>
                    <div className="modal-dialog modal-dialog-centered">
                        <div className="modal-content">
                            <div className="modal-header">
                                <p className="lead text-info font-weight-bold text-center">Create New Blog Post</p>
                                <button type="button" className="close" onClick={cancelCreate} data-dismiss="modal">
                                    <span>&times;</span>
                                </button>
                            </div>
                            <div>
                                <form className="form-group mx-3">
                                    <br />
                                    <input type="number" className="mx-3 py-3" name="userId" id="userId"
                                        value={postToPublish.userId}
                                        onChange={handlecreate}
                                        placeholder="Enter your userId"
                                        autoFocus /><br />
                                    <br />
                                    <p className="mx-3 my-3">TITLE:</p>
                                    <br />
                                    <textarea class="form-control container-fluid " name="title" id="title" value={postToPublish.title} onChange={handlecreate} placeholder="Enter blog title" /><br />
                                    <p className="mx-3 my-3">BODY:</p>
                                    <br /><textarea class="form-control container-fluid " name="body" id="body" value={postToPublish.body} onChange={handlecreate} placeholder="Enter content" /><br />
                                    <input type="button" value="Create Post" className="btn btn-outline-dark mt-3 mb-3" onClick={postBlogData} />
                                </form>
                            </div>
                        </div>
                    </div>
                    <div className="container text-center font-italic font-weight-bolder">
                        <p className="text-dark">To Delete a post</p>
                        <Link className="nav-link text-warning" to="/deletepost">Click here!!</Link>
                    </div>
                </div>
                <hr className="text-light" />
                <h3 className="font-weight-bolder text-dark bg-light font-italic text-center">According to Trends</h3>
                <h5 className="font-italic text-muted mx-3 my-3">  If your blog post is a news-oriented channel, you should publish articles on trending topics as quickly as it’s convenient for you to do so. Covering trends won’t allow you to create a content plan for a specific time period, but you can still produce evergreen content in the background to support your online visibility.

                    Do you organize your blog differently? Share how you usually prioritize your blog topics and how it works for you in the comments below.

                    Empo</h5>
            </div>
        </div>
    );


}
export default CreatePost;