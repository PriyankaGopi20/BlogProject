import { useState } from "react";
//import { deleteBlog } from "../services/AppUserService";
import { setBlogObj } from "../redux/BlogSlice";
import { useDispatch } from "react-redux";
import axios from "axios";

const DeletePost = () => {
    const url = `http://localhost:12345`;
    const [id, setId] = useState('');
    const dispatch = useDispatch();


    const submitDeletePostById = (evt) => {
        console.log(`submitDeletePostById ${id}`);
        axios.delete(`${url}/posts/${id}`)
            .then((response) => {
                console.log(response.data);
                dispatch(setBlogObj(response.data));
                alert(`Successfully deleted!`);
            })
            .catch((error) => {
                console.log(error.message);
                alert(`Blog with ${id} not found ${error.message}.`);
            });
        evt.preventDefault();
    };

    const handleId = (evt) => {
        console.log(`${evt.target.name} ${evt.target.value}`);
        setId(evt.target.value);
    };
    return (
        <div
            style={{
                backgroundImage: `url("https://thumbs.dreamstime.com/b/grey-tech-background-abstract-vector-33109515.jpg")`,
                height: "600px"
            }} >
            <h3 className="text-center font-italic text-light font-weight-bold">Are you sure!!!</h3>
            <div className="container row">
                <div className="col-3"></div>
                <form className="col-5">
                    <input type="number" className="mx-3 my-3" onChange={handleId} value={id} placeholder="Enter the blog id" />
                    <input type="button" value="Delete post" className="btn btn-outline-dark mx-3 my-3" onClick={submitDeletePostById} />
                </form>
            </div>
        </div>

    )

}
export default DeletePost;