// import { useState,useEffect } from "react";
// import AppUser from "../models/AppUser";
import { Link } from "react-router-dom";
const Header = () => {

    const currentUser = sessionStorage.getItem(`loginStatus`);
    // const [currentUser, setCurrentUser] = useState(new AppUser());

    // useEffect(() => {
    //     setCurrentUser(sessionStorage.getItem(`loginStatus`));
    // }, []);

    return (
            <div>
                {currentUser &&
                    <div>
                        <nav className="navbar navbar-expand-lg navbar-info bg-dark ">
                            <Link className="navbar-brand" to="/home"><img height="24px" src="https://brandpalettes.com/wp-content/uploads/2020/06/deloitte-02.png" alt="Deloitte"></img> </Link>
                            <Link className="navbar-brand text-muted" to="/home">Home</Link>
                            <button className="navbar-toggler btn btn btn-outline-info" type="button" data-toggle="collapse" data-target="#navbarSupportedContent">
                                <span className="navbar-toggler-icon"></span>
                            </button>
                            <div className="collapse navbar-collapse " id="navbarSupportedContent">
                                <ul className="navbar-nav mr-auto">
                                    <li className="nav-item">
                                        <Link className="nav-link text-muted" to="/readpost">ReadPost</Link>
                                    </li>
                                    <li className="nav-item">
                                        <Link className="nav-link text-muted" to="/home">Home</Link>
                                    </li>
                                    <li className="nav-item">
                                        <Link className="nav-link text-muted" to="/createpost">CreatePost</Link>
                                    </li>
                                    <li className="nav-item">
                                        <Link className="nav-link text-muted" to="/updatepost">UpdatePost</Link>
                                    </li>
                                    <li className="nav-item">
                                        <Link className="nav-link text-muted" to="/logout">Logout</Link>
                                    </li>
                                    <li className="nav-item">
                                        <Link className="nav-link text-muted" to="/deletepost">DeletePost</Link>
                                    </li>
                                    <li className="nav-item">
                                        <Link className="nav-link text-muted" to="/updatecomment">updatecomment</Link>
                                    </li>


                                </ul>
                            </div>
                        </nav>
                    </div>
                }
                
                {!currentUser &&
                    <div>
                        <nav className="navbar navbar-expand-lg navbar-info bg-dark ">
                            <Link className="navbar-brand" to="/home"><img height="24px" src="https://brandpalettes.com/wp-content/uploads/2020/06/deloitte-02.png" alt="Deloitte"></img> </Link>
                            <Link className="navbar-brand text-muted" to="/home">Home</Link>
                            <button className="navbar-toggler btn btn btn-outline-info" type="button" data-toggle="collapse" data-target="#navbarSupportedContent">
                                <span className="navbar-toggler-icon"></span>
                            </button>
                            <div className="collapse navbar-collapse " id="navbarSupportedContent">
                                <ul className="navbar-nav mr-auto">
                                    <li className="nav-item">
                                        <Link className="nav-link text-muted" to="/register">Register</Link>
                                    </li>
                                    <li className="nav-item">
                                        <Link className="nav-link text-muted" to="/login">Login</Link>
                                    </li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                }

            </div>
        
    );

}
export default Header;