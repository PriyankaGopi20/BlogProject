
const Home = () => {

    // return (
    //     <div>
    //         <p>Home component</p>
    //     </div>
    // );

    return (
        <div
            style={{
                backgroundImage: `url("https://media.istockphoto.com/vectors/grey-wheel-geometric-technology-background-with-gear-shape-vector-vector-id882715274?k=6&m=882715274&s=170667a&w=0&h=h66YBsPJwgY3xo8zbl3Tmq1ktTQYoWrsK4Phpe6263A=")`,
}} >
    <div style={{ minHeight: "100vh", textShadow: '2px 2px #cccccc' }} className="container">
        <p className="display-4 text-dark pt-5">DELOITTE BLOGGER SITE</p>
        <p>Welcome to Deloitte Blogger site!!</p>
        {/* <img src="https://www.enjpg.com/img/2020/rainbow-aesthetic-1.jpg"></img> */}

    </div>
        </div >
    );
}

export default Home;