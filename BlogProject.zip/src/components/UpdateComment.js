import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import PostComment from "../models/PostComment";
import { setBlogObj } from "../redux/BlogSlice";
import { useDispatch } from "react-redux";

const UpdateComment = (props) => {
    const url = `http://localhost:12345`;
    const [commentToUpdate, setCommentToUpdate] = useState({});
    const navigate = useNavigate();
    const dispatch = useDispatch();

    useEffect(
        () => {
            setCommentToUpdate(new PostComment());
        }
        ,
        []
    );

    const submitUpdatePost = (evt) => {
        console.log(submitUpdatePost);
        axios.put(`${url}/comments/${commentToUpdate.id}`, commentToUpdate)
            .then((response) => {
                console.log(response.data);
                dispatch(setBlogObj(response.data));
                setCommentToUpdate({id:``,blogcomment:``});
                alert(`Post for ID ${response.data.id} updated successfully!`);
            })
            .catch((error) => {
                console.log(error.message);
                alert(`Post could not be updated ${error.message}.`)
            });
        evt.preventDefault();
    };
    const handleUpdate = (evt) => {
        setCommentToUpdate({ ...commentToUpdate, [evt.target.name]: evt.target.value });
    }

    return (
        <div className="container">
        <div
            style={{
                backgroundImage: `url("https://thumbs.dreamstime.com/b/grey-tech-background-abstract-vector-33109515.jpg")`,
                height: "900px"
            }} >
            <div className="col-5 mx-3 py-3 bg-white shadow">
                <p className="lead">Update your comment!!</p>
                <hr />
                <div>
                <form>
                    <input
                        type="number"
                        name="id"
                        value={commentToUpdate.id}
                        onChange={handleUpdate}
                        className="form-control mr-2"
                        placeholder="Enter id"
                    />
                    <input
                        type="text"
                        name="body"
                        value={commentToUpdate.blogcomment}
                        className="form-control mt-3 mb-3"
                        placeholder="Enter the description"
                        onChange={handleUpdate}
                    />
                    <input
                        type="button"
                        value="Update comment"
                        className="btn btn-outline-dark mt-3 mb-3"
                        onClick={submitUpdatePost}
                    />
                </form>
                </div>
            </div>
            <hr />
            <p className="text-warning font-bold">FOR ANY QUERIES READ BELOW!!!</p>
            <h6 className="text-light font-italic">If you have any issues regarding the updation of blog kindly contact the helpline which is provided in the helpdesk..And if your facing any troubleshoot problem follow the steps to quick fix the problem..</h6>
        </div>
        </div>
    )

}
export default UpdateComment;