
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { setLoggedInUser } from '../redux/AppUserSlice';

const Logout = () => {

    const dispatch = useDispatch();
    const navigate = useNavigate();

    const submitLogout = () => {
        if (window.confirm('Are you sure to logout?')) {
            dispatch(setLoggedInUser(''));
            sessionStorage.removeItem(`loginStatus`);
            navigate(`/home`);
            window.location.reload();
        }
        else {
            navigate(-1);
        }
    };


    return (
        <div className="container">
            <div
                style={{
                    backgroundImage: `url("https://st2.depositphotos.com/3784595/10731/i/950/depositphotos_107315890-stock-photo-cancel-button-on-keyboard.jpg")`,
                    height: "600px"
                }} >

                <p className="display-4 text-dark py-3 text-center font-weight-bold font-italic ">Logout</p>
                <hr />

                <div className="row">
                    <div className="col-4"></div>
                    <div className="col-4 mt-3 py-3 shadow bg-white" >
                        <h1 className="lead text-info font-weight-bold pb-2 text-center">Logout</h1>
                        <form className="form form-group form-dark col-12">
                            <div>
                                <input
                                    type="button"
                                    id="submit"
                                    name="submit"
                                    className="form-control btn btn-outline-secondary font-italic"
                                    value="Click to Logout"
                                    onClick={submitLogout}
                                />
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );

}
export default Logout;



