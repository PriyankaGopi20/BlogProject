import axios from "axios";
import { useEffect, useState } from "react";
import Post from "../models/Post";
import BlogPostComment from "./BlogPostComment";
import { useSelector, useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";


const ReadPost = () => {

    const url = `http://localhost:12345`;
    const [todaysPost, setTodaysPost] = useState({});
    const allBlogList = useSelector(store => store.myBlogComment.blogList);
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const [commentsForThisBlogPost, setCommentsForThisBlogPost] = useState([]);
    let cmts = ``;

    useEffect(
        () => {
            setTodaysPost(new Post());
            console.log(todaysPost.id);
        }
        ,
        []
    );

    const getBlogPostData = (evt) => {
        console.log(`getBlogPostData`);
        let num = ``;
        axios.get(`${url}/posts/${todaysPost.search}`)
            .then((response) => {
                console.log(response.data);
                setTodaysPost(response.data);
                num = response.data.id;
            }).catch((error) => {
                console.log(error.message);
                alert(`Post with postId ${todaysPost.search} not found!`);
            });
        console.log(todaysPost.search);

        axios.get(`${url}/comments?postId=${todaysPost.search}`)
            .then((response) => {
                console.log(response.data);
                cmts = response.data;
                console.log(cmts);
                setCommentsForThisBlogPost(response.data);
                console.log(commentsForThisBlogPost.length);
            })
            .catch(e => console.log(e));

        evt.preventDefault();
    }

    const handleSearch = (evt) => {
        setTodaysPost({ ...todaysPost, [evt.target.name]: evt.target.value });
    }
    const cancelCreate = () => {
        navigate(-1);
    };


    return (
        <div
            style={{
                backgroundImage: `url("https://thumbs.dreamstime.com/b/grey-tech-background-abstract-vector-33109515.jpg")`,

            }} >

            <div>
                <div>
                    <p className="lead text-info font-weight-bold font-italic text-center display-4" id="exampleModalLabel">VIEW A BLOG POST</p>
                    <button type="button" className="close" onClick={cancelCreate}>
                        <span>&times;</span>
                    </button>
                    <input type="text" name="search" id="search" value={todaysPost.search} onChange={handleSearch} className="mx-4 my-4 bx-4 by-4" autoFocus />
                    <input type="button" value="View Post" className="btn btn-outline-info mb-3" onClick={getBlogPostData} />
                </div>

                <div className="text-light">
                    <form className="form-group mx-4 my-4 bx-4 by-4">
                        <div>
                            <p className="font-weight-bold">TITLE:</p>{todaysPost.title}
                            <p className="font-weight-bold">USERID:</p> {todaysPost.userId}
                            <p className="font-weight-bold">ID: </p>{todaysPost.id}
                            <p className="font-weight-bold">DESCRIPTION:</p>{todaysPost.body}

                        </div>
                    </form>
                </div>
                <hr />

                <div>
                    <div className=" mx-3 my-3 px-3 py-3 bg-white shadow">
                        <p className="lead font-bold text-info">VIEW COMMENTS</p>
                        <hr />
                        <div >
                            <p>{cmts}</p>
                            {commentsForThisBlogPost &&
                                commentsForThisBlogPost.map((cmt =>
                                    <div>
                                        <p> {cmt.body} </p>
                                    </div>
                                ))
                            }

                            <div>
                                {
                                    (todaysPost.id === allBlogList.postId) &&
                                    <div>
                                        <hr />
                                        {
                                            <table className="table">
                                                <thead>
                                                    <tr>
                                                        <th>BLOGID</th>
                                                        <th>BLOG COMMENT</th>
                                                    </tr>
                                                </thead>
                                                {allBlogList.map((b =>
                                                    <tbody>
                                                        <tr>
                                                            <td>{b.id}</td>
                                                            <td>{b.blogcomment}</td>
                                                        </tr>
                                                    </tbody>
                                                ))}
                                            </table>
                                        }
                                    </div>
                                }
                            </div>
                        </div>
                    </div>

                </div>
                <div>
                    <BlogPostComment
                        idFromRead={todaysPost.id} />
                </div>
                <hr />
            </div>
        </div >

    );

}

export default ReadPost;