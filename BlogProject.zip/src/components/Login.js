import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { setLoggedInUser, setAppUsersList } from '../redux/AppUserSlice';
import { findAllAppUsers, login } from '../services/AppUserService';
import CreatePost from "./CreatePost";

import AppUser from "../models/AppUser";

const Login = () => {

    const dispatch = useDispatch();
    const navigate = useNavigate();
    const [appUserToLogin, setAppUserToLogin] = useState({});
    const usersList = useSelector(store => store.appUser.appUsersList);

    useEffect(() => {
        setAppUserToLogin(new AppUser());
        findAllAppUsers()
            .then(resp => dispatch(setAppUsersList(resp.data)))
            .catch(err => console.log(err.message));
    },
        [dispatch]);

    const handleAppUserToLogin = (event) => {
        setAppUserToLogin({
            ...appUserToLogin,
            [event.target.name]: event.target.value
        });
    };

    const submitLogin = (event) => {
        let tempUser = {};
        console.log(`submitLogin`);
        usersList.forEach(element => {
            if (element.userName === appUserToLogin.userName) {
                tempUser = element;
            }
        });

        if (tempUser.userName === appUserToLogin.userName && tempUser.password === appUserToLogin.password) {
            setAppUserToLogin(tempUser);
            login(tempUser)
                .then((response) => {
                    sessionStorage.setItem(`loginStatus`, response.data);
                    console.log(response.data);
                    dispatch(setLoggedInUser(response.data));
                    alert(`User ${response.data.userName} logged in successfully! Navigating to Home...`);
                    navigate(`/home`);
                    window.location.reload();
                })
                .catch((err) => {
                    console.log(err.message);
                    alert(err.message);
                });
        }
        else {
            setAppUserToLogin({ userName: '', password: '' });
            alert(`Invalid credentials!`);
        }


        event.preventDefault();
    }

    return (
        <div class="bg-secondary">
            <div class="container">
                <div class="text-center font-italic text-light bg-muted px-3 py-3 mx-3">
                    <p>Welcome to the login page! If you already have an account then login or <nav className="navbar navbar-expand-lg">
                        <Link className="navbar-brand text-warning" to="/register">Register Now!</Link></nav></p>
                    <hr />
                </div>
                <div class="row">

                    <div class="col-4"></div>
                    <div class="bg-white shadow col-4">
                        <p class="display-4 text-dark bg-light text-center font-weight-bolder bx-3">LOGIN</p>
                        <form className="form form-group form-dark ">
                            <div>
                                <input
                                    type="text"
                                    name="userName"
                                    id="userName"
                                    className="form-control mb-3"
                                    placeholder="Enter username"
                                    value={appUserToLogin.userName}
                                    onChange={handleAppUserToLogin}
                                    required
                                />
                                <input
                                    type="password"
                                    name="password"
                                    id="password"
                                    className="form-control mb-3"
                                    placeholder="Enter password"
                                    value={appUserToLogin.password}
                                    onChange={handleAppUserToLogin}
                                    required
                                />
                                <div class="form-group">
                                    <select class="form-control mb-3" name="role" id="role" onChange={handleAppUserToLogin}>
                                        <option value="Role">Select a role</option>
                                        <option value={appUserToLogin.role}>ADMIN</option>
                                        <option value={appUserToLogin.role}>BLOGGER</option>
                                        <option value={appUserToLogin.role}>READER</option>
                                    </select>
                                </div>
                                <input
                                    type="button"
                                    id="submit"
                                    name="submit"
                                    className="form-control btn btn-outline-info"
                                    value="Login"
                                    onClick={submitLogin}
                                />
                            </div>
                        </form>
                    </div>
                </div>
                {/* <div class="row">
                    <div className="col-4"></div>
                <div className="py-3 col-7">
                    <Link to="/register" className="btn btn-outline-primary col-3">Not yet registered? Register</Link>
                </div>
                </div> */}

            </div >

        </div>
    )
}
export default Login;



