const BloggerLogin=()=>{
    return(
        <div>
            <p>This is BloggerLogin component</p>
        </div>
    )
}