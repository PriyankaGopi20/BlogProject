import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import PostComment from "../models/PostComment";
import { setBlogObj } from "../redux/BlogSlice";
import { useDispatch } from "react-redux";

const BlogPostComment = (props) => {
    const url = `http://localhost:12345`;
    const [commentToCreate, setCommentToCreate] = useState({});
    const navigate = useNavigate();
    const [id, setId] = useState('');
    const currentBlogId = props.idFromRead;
    const dispatch = useDispatch();

    useEffect(
        () => {
            setCommentToCreate(new PostComment());
        }
        ,
        []
    );

    const postBlogComment = (evt) => {
        axios.post(`${url}/comments/`, commentToCreate)
            .then((response) => {
                console.log(response.data);
                alert(`The comment for ${response.data.id} has been successfully created!!`);
            }).catch((error) => {
                console.log(error.message);
            });
        evt.preventDefault();
    }
    const cancelCreate = () => {
        navigate(-1);
    };

    const submitDeleteCommentById = (evt) => {
        console.log(`submitDeleteCommentById ${id}`);
        axios.delete(`${url}/comments/${id}`)
            .then((response) => {
                console.log(response.data);
                dispatch(setBlogObj(response.data));
                alert(`The Comment for ${response.data.title} has been deleted!`)
            })
            .catch((error) => {
                console.log(error.message);
                alert(`Blog with ${id} not found ${error.message}.`);
            });
        evt.preventDefault();
    };


    const handleId = (evt) => {
        console.log(`${evt.target.name} ${evt.target.value}`);
        setId(evt.target.value);
    };
    const handlecreate = (evt) => {
        setCommentToCreate({ ...commentToCreate, [evt.target.name]: evt.target.value })
    }

    return (

        <div>
            <div>
                <div>
                    <div>
                        <p className="lead text-info mx-5 my-5 bx-5 by-5" id="exampleModalLabel">Write your comments here!</p>
                        <button type="button" className="close" onClick={cancelCreate} data-dismiss="modal">
                            <span>&times;</span>
                        </button>
                    </div>
                    <div>
                        <form className="form-group mx-5 my-5 bx-5 by-5">
                            <p className="text-muted">USER ID:</p>
                            <input type="number" name="UserId" id="UserId" value={commentToCreate.userId} onChange={handlecreate} placeholder="Enter UserId" /><br />
                            <p className="text-muted col-10">POST ID:</p>
                            <input type="number"name="postId" id="postId" value={currentBlogId} onChange={handlecreate} placeholder="Enter PostId"/><br />
                            <p className="text-muted">BLOG COMMENT:</p>
                            <textarea class="form-control container-fluid " name="blogcomment" id="blogcomment" value={commentToCreate.blogcomment} onChange={handlecreate} placeholder="Enter content" /><br />
                            <input type="button" value="Create Comment" className="btn btn-outline-info mt-3 mb-3" onClick={postBlogComment} />
                        </form>
                    </div>

                    <div className="container mx-5 my-5 bx-5 by-5">
                        <p className="font-weight-bold text-light">You can delete the comment below!!!</p>
                        <form>
                            <input type="number" onChange={handleId} value={id} placeholder="Enter the blog id" />
                            <input type="button" value="Delete comment" className="btn btn-outline-dark mt-3 mb-3" onClick={submitDeleteCommentById} />
                        </form>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default BlogPostComment;