import { createSlice } from '@reduxjs/toolkit';
import Post from '../models/Post';


const BlogSlice = createSlice({

    name: `blog`, // identifier for this slice 

    initialState: {

        blogObj: new Post(),
    },

    reducers: {

        setBlogObj: (state, action) => {
            console.log(action.payload);
            state.empObj = action.payload;
        }
    } 
});

export const { setBlogObj } = BlogSlice.actions;
export default BlogSlice.reducer;