import { createSlice } from '@reduxjs/toolkit';
import PostComment from '../models/PostComment';


const BlogSlice = createSlice({

    name: `myBlogComment`, // identifier for this slice 

    initialState: {

        blogObj: new PostComment(),
        blogList: []
    },

    reducers: {

        setBlogObj: (state, action) => {
            console.log(action.payload);
            state.blogObj = action.payload;
        },
        setBlogList: (state, action) => {
            console.log(action.payload);
            state.blogList = action.payload;
        }

    } 
});

export const { setBlogObj ,setBlogList} = BlogSlice.actions;
export default BlogSlice.reducer;