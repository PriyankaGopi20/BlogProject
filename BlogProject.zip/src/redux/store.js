import { configureStore } from "@reduxjs/toolkit";
import appUserReducer from './AppUserSlice';
import  blogReducer from './BlogSlice';
import  blogCommentReducer from './PostCommentSlice';


const store = configureStore({
    reducer: {
        blog:blogReducer,
        appUser: appUserReducer,
        myBlogComment:blogCommentReducer
    }
});
export default store;