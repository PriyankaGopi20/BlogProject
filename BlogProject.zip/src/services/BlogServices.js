import axios from 'axios';

const url = `http://localhost:12345/posts`;

// const findAllUsers = () => {
//     console.log(`findAllUsers`);
//     return axios.get(url);
// }

// const updateBlog = (emp) => {
//     console.log(`updateEmployee${emp}`);
//     return axios.put(`${url}/${emp.id}`, emp);
// }

const deleteBlog = (id) => {
    return axios.delete(`${url}/${id}`);
}

export { deleteBlog };
